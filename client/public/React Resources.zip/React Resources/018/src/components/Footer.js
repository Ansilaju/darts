import "./Footer.css";

export const Footer = () => {
  return (
    <footer>
        <p>2030 - TaskMate</p>
    </footer>
  )
}
