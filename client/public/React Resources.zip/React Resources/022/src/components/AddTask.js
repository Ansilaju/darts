import "./AddTask.css";

export const AddTask = () => {
  return (
    <section className="addtask">
      <form>
        <input type="text" placeholder="Task Name" name="task" id="task" autoComplete="off" />
        <button>Add Task</button>
      </form>
    </section>
  )
}
