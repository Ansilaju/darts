export const Contact = () => {
  return (
    <div>Contact</div>
  )
}
